﻿using COdeDocGenerator1.API.Models;
using System.Text;

namespace COdeDocGenerator1.Services
{
    public static class DocumentationPromptBuilder
    {
        // SINGLE FILE DOCUMENTATION
        public static string BuildPrompt(ParsedCodeResponse file, string documentType)
        {
            var sb = new StringBuilder();

            sb.AppendLine($"DOCUMENT TYPE: {documentType}");
            sb.AppendLine($"FILE NAME: {file.FileName}");
            sb.AppendLine();

            sb.AppendLine("CLASSES AND METHODS:");

            foreach (var cls in file.Classes)
            {
                sb.AppendLine($"Class: {cls.ClassName}");

                foreach (var method in cls.Methods)
                {
                    sb.AppendLine($"  Method: {method.MethodName}");
                    sb.AppendLine($"  Returns: {method.ReturnType}");
                    sb.AppendLine($"  Parameters: {method.Parameters}");
                }
            }

            sb.AppendLine();
            sb.AppendLine("DEPENDENCIES:");
            sb.AppendLine(string.Join(", ", file.Dependencies ?? new List<string>()));

            sb.AppendLine();
            sb.AppendLine("SQL CALLS:");
            sb.AppendLine(string.Join(", ", file.SqlCalls ?? new List<string>()));

            sb.AppendLine();
            sb.AppendLine("SESSION USAGE:");
            sb.AppendLine(string.Join(", ", file.SessionUsage ?? new List<string>()));

            sb.AppendLine();
            sb.AppendLine("VIEWSTATE USAGE:");
            sb.AppendLine(string.Join(", ", file.ViewStateUsage ?? new List<string>()));

            sb.AppendLine();
            sb.AppendLine("Generate professional developer documentation with headings.");

            return sb.ToString();
        }

        // MULTI FILE (ARCHITECTURE)
        public static string BuildMultiFilePrompt(List<ParsedCodeResponse> files)
        {
            var sb = new StringBuilder();

            sb.AppendLine("Generate Software Architecture Documentation.");
            sb.AppendLine($"Total Files: {files.Count}");
            sb.AppendLine();

            foreach (var file in files)
            {
                sb.AppendLine($"File: {file.FileName}");

                foreach (var cls in file.Classes)
                {
                    sb.AppendLine($" Class: {cls.ClassName}");

                    foreach (var method in cls.Methods)
                    {
                        sb.AppendLine($"  Method: {method.MethodName}");
                    }
                }

                sb.AppendLine();
            }

            sb.AppendLine("Explain:");
            sb.AppendLine("1. System Overview");
            sb.AppendLine("2. Architecture");
            sb.AppendLine("3. Module Responsibilities");
            sb.AppendLine("4. Flow Between Components");

            return sb.ToString();
        }
    }
}