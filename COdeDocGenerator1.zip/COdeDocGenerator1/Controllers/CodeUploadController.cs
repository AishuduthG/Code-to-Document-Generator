﻿using Microsoft.AspNetCore.Mvc;
using COdeDocGenerator1.API.Services;
using COdeDocGenerator1.API.Models;
using COdeDocGenerator1.Services;

namespace COdeDocGenerator1.API.Controllers
{
    [ApiController]
    [Route("api/code")]
    public class CodeUploadController : ControllerBase
    {
        private readonly ICodeParserService _parser;
        private readonly IAiExplanationService _aiService;

        public CodeUploadController(
            ICodeParserService parser,
            IAiExplanationService aiService)
        {
            _parser = parser;
            _aiService = aiService;
        }

        [HttpPost("upload")]
        public async Task<IActionResult> UploadCode([FromForm] DocumentRequest request)
        {
            if (request.Files == null || request.Files.Count == 0)
                return BadRequest("No files uploaded.");

            var parsedFiles = new List<ParsedCodeResponse>();

            foreach (var file in request.Files)
            {
                using var reader = new StreamReader(file.OpenReadStream());
                var content = await reader.ReadToEndAsync();

                var parsed = _parser.ParseCode(content, file.FileName);
                parsedFiles.Add(parsed);
            }

            if (!parsedFiles.Any())
                return BadRequest("No valid code files found.");

            string prompt;

            if (request.DocumentType.ToLower() == "architecture")
            {
                prompt = DocumentationPromptBuilder.BuildMultiFilePrompt(parsedFiles);
            }
            else
            {
                prompt = DocumentationPromptBuilder.BuildPrompt(parsedFiles.First(), request.DocumentType);
            }

            var documentation = await _aiService.GenerateDocumentationAsync(prompt);

            return Ok(new
            {
                DocumentType = request.DocumentType,
                FilesProcessed = parsedFiles.Count,
                Documentation = documentation
            });
        }
    }
}