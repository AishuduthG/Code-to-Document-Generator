﻿using COdeDocGenerator1.API.Models;

namespace COdeDocGenerator1.API.Models
{
    public class ParsedCodeResponse
    {
        public List<ParsedClassModel> Classes { get; set; } = new();
        public string FileName { get; set; } = string.Empty;

        public string Overview { get; set; } = string.Empty;

        public List<string> Dependencies { get; set; } = new();

        public List<string> PageEvents { get; set; } = new();
        public List<string> ButtonEvents { get; set; } = new();
        public List<string> GridBindings { get; set; } = new();

        public List<string> SqlCalls { get; set; } = new();
        public List<string> StoredProcedures { get; set; } = new();

        public List<string> SessionUsage { get; set; } = new();
        public List<string> ViewStateUsage { get; set; } = new();

        public List<string> Redirects { get; set; } = new();
        public List<string> TryCatchBlocks { get; set; } = new();

        public List<string> PossibleSqlInjection { get; set; } = new();
        public List<string> ComplexMethods { get; set; } = new();
        public List<string> HardcodedValues { get; set; } = new();

        public int TotalMethods { get; set; }

        public int HighComplexityCount { get; set; }

        public string Documentation { get; set; } = string.Empty;

        public string FileType { get; set; } = string.Empty;


    }
}
