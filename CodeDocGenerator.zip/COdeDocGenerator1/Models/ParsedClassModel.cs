﻿

namespace COdeDocGenerator1.API.Models
{
    public class ParsedClassModel
    {
        public string ClassName { get; set; }
        public List<ParsedMethodModel> Methods { get; set; } = new();
        public string Summary { get; set; } = string.Empty;
        public string Overview { get; set; } = string.Empty; 
    }
}
