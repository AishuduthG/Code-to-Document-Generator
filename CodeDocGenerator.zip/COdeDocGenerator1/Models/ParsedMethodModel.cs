﻿namespace COdeDocGenerator1.API.Models
{
    public class ParsedMethodModel
    {
        public string MethodName { get; set; }
        public string ReturnType { get; set; }
        public string Parameters { get; set; }
        public bool IsAsync { get; set; }
        public int StatementCount { get; set; }
        public string XmlComment { get; set; }

        public string Description { get; set; } = string.Empty;
    }

}
