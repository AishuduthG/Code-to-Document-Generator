﻿namespace COdeDocGenerator1.API.Models
{
    public class DocumentRequest
    {
        
        public string DocumentType { get; set; }
        public List<IFormFile> Files { get; set; } = new();
    }
}
