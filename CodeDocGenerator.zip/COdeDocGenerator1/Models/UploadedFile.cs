﻿namespace COdeDocGenerator1.API.Models
{
    public class UploadedFile
    {
        public string FileName { get; set; }

        public string Content { get; set; }
    }
}