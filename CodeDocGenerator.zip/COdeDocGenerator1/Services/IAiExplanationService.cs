﻿namespace COdeDocGenerator1.API.Services
{
    public interface IAiExplanationService
    {
        Task<string> GenerateDocumentationAsync(string prompt);
    }
}
