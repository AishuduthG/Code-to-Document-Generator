﻿using COdeDocGenerator1.API.Models;
using COdeDocGenerator1.API.Services;
using Microsoft.AspNetCore.Http;

namespace COdeDocGenerator1.Services
{
    public class DocumentGeneratorService : IDocumentGeneratorService
    {
        private readonly IAiExplanationService _aiService;

        public DocumentGeneratorService(IAiExplanationService aiService)
        {
            _aiService = aiService;
        }

        public async Task<ParsedCodeResponse> GenerateDocumentationAsync(IFormFile file)
        {
            // This method is optional depending on your flow
            var response = new ParsedCodeResponse
            {
                FileName = file.FileName,
                Overview = "Documentation generated."
            };

            return await Task.FromResult(response);
        }

        public async Task<string> GenerateAsync(List<ParsedCodeResponse> parsedFiles, string docType)
        {
            string prompt;

            switch (docType.ToLower())
            {
                case "architecture":
                    prompt = DocumentationPromptBuilder.BuildMultiFilePrompt(parsedFiles);
                    break;

                default:
                    prompt = "Generate professional software documentation.";
                    break;
            }

            return await _aiService.GenerateDocumentationAsync(prompt);
        }
    }
}