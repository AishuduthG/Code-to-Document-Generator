﻿using System.Text;
using COdeDocGenerator1.API.Models;

namespace COdeDocGenerator1.API.Services
{
    public class PromptBuilderService : IPromptBuilderService
    {
        public string BuildDocumentationPrompt(ParsedCodeResponse parsedCode)
        {
            var prompt = new StringBuilder();

            prompt.AppendLine("You are a senior software architect.");
            prompt.AppendLine("Generate clean technical documentation with feature explanations.");
            prompt.AppendLine("Use professional formatting and headings.");
            prompt.AppendLine();

            foreach (var cls in parsedCode.Classes)
            {
                prompt.AppendLine($"Class: {cls.ClassName}");

                foreach (var method in cls.Methods)
                {
                    prompt.AppendLine($"Method: {method.MethodName}");
                    prompt.AppendLine($"Return Type: {method.ReturnType}");
                    prompt.AppendLine($"Parameters: {method.Parameters}");
                    prompt.AppendLine($"Async: {method.IsAsync}");
                    prompt.AppendLine($"Statements: {method.StatementCount}");
                    prompt.AppendLine($"Comments: {method.XmlComment}");
                    prompt.AppendLine();
                }
            }

            return prompt.ToString();
        }
    }
}
