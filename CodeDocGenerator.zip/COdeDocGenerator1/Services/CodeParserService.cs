﻿using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using COdeDocGenerator1.API.Models;
using Microsoft.CodeAnalysis;

namespace COdeDocGenerator1.API.Services
{
    public class CodeParserService : ICodeParserService
    {
        public ParsedCodeResponse ParseCode(string sourceCode, string fileName)
        {
            var response = new ParsedCodeResponse
            {
                FileName = fileName
            };

            var tree = CSharpSyntaxTree.ParseText(sourceCode);
            var root = tree.GetRoot();

            var usings = root.DescendantNodes()
                             .OfType<UsingDirectiveSyntax>();

            foreach (var u in usings)
            {
                response.Dependencies.Add(u.Name.ToString());
            }

            var classes = root.DescendantNodes()
                              .OfType<ClassDeclarationSyntax>();

            foreach (var cls in classes)
            {
                var classModel = new ParsedClassModel
                {
                    ClassName = cls.Identifier.Text
                };

                var methods = cls.DescendantNodes()
                                 .OfType<MethodDeclarationSyntax>();

                foreach (var method in methods)
                {
                    var methodName = method.Identifier.Text;

                    response.TotalMethods++;

                    int statementCount =
                        method.Body?.Statements.Count ?? 0;

                    if (statementCount > 20)
                    {
                        response.ComplexMethods.Add(methodName);
                        response.HighComplexityCount++;
                    }

                    classModel.Methods.Add(new ParsedMethodModel
                    {
                        MethodName = methodName,
                        ReturnType = method.ReturnType.ToString(),
                        Parameters = method.ParameterList.ToString(),
                        IsAsync = method.Modifiers.Any(m => m.Text == "async"),
                        StatementCount = statementCount
                    });


                    if (methodName.Contains("Page_Load") ||
                        methodName.Contains("Page_Init"))
                    {
                        response.PageEvents.Add(methodName);
                    }

                    if (methodName.EndsWith("_Click"))
                    {
                        response.ButtonEvents.Add(methodName);
                    }

                    var sqlObjects = method.DescendantNodes()
                        .OfType<ObjectCreationExpressionSyntax>()
                        .Where(x => x.Type.ToString().Contains("Sql"));

                    foreach (var sql in sqlObjects)
                    {
                        response.SqlCalls.Add(sql.Type.ToString());
                    }

                    var spStrings = method.DescendantNodes()
                        .OfType<LiteralExpressionSyntax>()
                        .Where(l => l.Token.ValueText.StartsWith("sp_"));

                    foreach (var sp in spStrings)
                    {
                        response.StoredProcedures.Add(sp.Token.ValueText);
                    }

                    var sessionAccess = method.DescendantNodes()
                        .OfType<ElementAccessExpressionSyntax>()
                        .Where(x => x.ToString().Contains("Session["));

                    foreach (var s in sessionAccess)
                    {
                        response.SessionUsage.Add(s.ToString());
                    }

                    if (method.ToString().Contains("ViewState["))
                    {
                        response.ViewStateUsage.Add(methodName);
                    }

                    if (method.ToString().Contains("Response.Redirect"))
                    {
                        response.Redirects.Add(methodName);
                    }

                    var tryBlocks = method.DescendantNodes()
                        .OfType<TryStatementSyntax>();

                    if (tryBlocks.Any())
                    {
                        response.TryCatchBlocks.Add(methodName);
                    }

                    if (method.ToString().Contains("+ \"select") ||
                        method.ToString().Contains("+ \"update") ||
                        method.ToString().Contains("+ \"delete"))
                    {
                        response.PossibleSqlInjection.Add(methodName);
                    }
                    var literals = method.DescendantNodes()
                        .OfType<LiteralExpressionSyntax>()
                        .Where(l => l.IsKind(SyntaxKind.StringLiteralExpression));

                    foreach (var literal in literals)
                    {
                        if (literal.Token.ValueText.Length > 10)
                        {
                            response.HardcodedValues.Add(literal.Token.ValueText);
                        }
                    }
                }

                response.Classes.Add(classModel);
            }

            return response;
        }

        public List<ParsedCodeResponse> ParseFiles(List<UploadedFile> files)
        {
            var result = new List<ParsedCodeResponse>();

            foreach (var file in files)
            {
                var parsed = ParseCode(file.Content, file.FileName);
                result.Add(parsed);
            }

            return result;
        }
    }
}
