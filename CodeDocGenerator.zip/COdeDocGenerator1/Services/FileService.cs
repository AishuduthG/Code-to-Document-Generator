﻿using System.IO.Compression;
using COdeDocGenerator1.API.Models;

namespace COdeDocGenerator1.API.Services
{
    public class FileService : IFileService
    {
        public async Task<string> ReadFileAsync(IFormFile file)
        {
            using var reader = new StreamReader(file.OpenReadStream());
            return await reader.ReadToEndAsync();
        }

        public async Task<List<UploadedFile>> ExtractZipAsync(IFormFile zipFile)
        {
            var files = new List<UploadedFile>();

            using var stream = new MemoryStream();
            await zipFile.CopyToAsync(stream);
            stream.Position = 0;

            using var archive = new ZipArchive(stream);

            foreach (var entry in archive.Entries)
            {
                if (string.IsNullOrEmpty(entry.Name))
                    continue;

                using var entryStream = entry.Open();
                using var reader = new StreamReader(entryStream);

                var content = await reader.ReadToEndAsync();

                files.Add(new UploadedFile
                {
                    FileName = entry.FullName,
                    Content = content
                });
            }

            return files;
        }

        public async Task<List<UploadedFile>> GetFilesFromUpload(List<IFormFile> files)
        {
            var result = new List<UploadedFile>();

            foreach (var file in files)
            {
                var ext = Path.GetExtension(file.FileName).ToLower();

                if (ext == ".zip")
                {
                    var zipFiles = await ExtractZipAsync(file);
                    result.AddRange(zipFiles);
                }
                else
                {
                    var content = await ReadFileAsync(file);

                    result.Add(new UploadedFile
                    {
                        FileName = file.FileName,
                        Content = content
                    });
                }
            }

            return result;
        }
    }
}