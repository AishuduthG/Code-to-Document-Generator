﻿using COdeDocGenerator1.API.Models;

namespace COdeDocGenerator1.API.Services
{
    public interface IFileService
    {
        Task<string> ReadFileAsync(IFormFile file);

        Task<List<UploadedFile>> ExtractZipAsync(IFormFile zipFile);

        Task<List<UploadedFile>> GetFilesFromUpload(List<IFormFile> files);
    }
}
