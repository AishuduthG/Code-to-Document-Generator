﻿using COdeDocGenerator1.API.Models;
using System.Text;

namespace COdeDocGenerator1.API.Services
{
    public class PromptBuilder
    {
        public static string CodeDocumentation(List<ParsedCodeResponse> files)
        {
            var sb = new StringBuilder();

            sb.AppendLine("Generate professional developer documentation.");
            sb.AppendLine();

            foreach (var file in files)
            {
                sb.AppendLine($"FILE: {file.FileName}");
                sb.AppendLine($"Overview: {file.Overview}");
                sb.AppendLine($"Total Methods: {file.TotalMethods}");
                sb.AppendLine();

                foreach (var cls in file.Classes)
                {
                    sb.AppendLine($"Class: {cls.ClassName}");

                    foreach (var method in cls.Methods)
                    {
                        sb.AppendLine($"  Method: {method.MethodName}");
                        sb.AppendLine($"  Returns: {method.ReturnType}");
                        sb.AppendLine($"  Parameters: {method.Parameters}");
                    }
                }

                sb.AppendLine("Dependencies:");
                sb.AppendLine(string.Join(", ", file.Dependencies));

                sb.AppendLine("Database Calls:");
                sb.AppendLine(string.Join(", ", file.SqlCalls));

                sb.AppendLine("Session Usage:");
                sb.AppendLine(string.Join(", ", file.SessionUsage));

                sb.AppendLine("-----------------------------------");
            }

            return sb.ToString();
        }

        public static string ArchitectureDocumentation(List<ParsedCodeResponse> files)
        {
            var sb = new StringBuilder();

            sb.AppendLine("Generate a complete SOFTWARE ARCHITECTURE DOCUMENT.");
            sb.AppendLine();

            sb.AppendLine("Include:");
            sb.AppendLine("1. System Overview");
            sb.AppendLine("2. Architecture Pattern");
            sb.AppendLine("3. Module Responsibilities");
            sb.AppendLine("4. Data Flow");
            sb.AppendLine("5. Database Interaction");
            sb.AppendLine("6. Security Considerations");
            sb.AppendLine("7. Scalability");

            sb.AppendLine();
            sb.AppendLine("Project Files:");

            foreach (var file in files)
            {
                sb.AppendLine($"File: {file.FileName}");
                sb.AppendLine($"Classes: {file.Classes.Count}");
                sb.AppendLine($"Methods: {file.TotalMethods}");
            }

            return sb.ToString();
        }
    }
}