﻿using COdeDocGenerator1.API.Models;

namespace COdeDocGenerator1.API.Services
{
    public interface IDocumentGeneratorService
    {
        Task<ParsedCodeResponse> GenerateDocumentationAsync(IFormFile file);
        Task<string> GenerateAsync(List<ParsedCodeResponse> parsedFiles, string docType);
    }
}
