﻿using COdeDocGenerator1.API.Models;

namespace COdeDocGenerator1.API.Services
{
    public interface IPromptBuilderService
    {
        string BuildDocumentationPrompt(ParsedCodeResponse parsedCode);
    }
}
