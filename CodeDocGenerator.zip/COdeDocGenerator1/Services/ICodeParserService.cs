﻿using COdeDocGenerator1.API.Models;
namespace COdeDocGenerator1.API.Services
{
    public interface ICodeParserService
    {
        ParsedCodeResponse ParseCode(string sourceCode, string fileName);

    }
}
