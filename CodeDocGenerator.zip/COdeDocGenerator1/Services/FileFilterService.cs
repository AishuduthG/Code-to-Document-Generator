﻿using COdeDocGenerator1.API.Models;

namespace COdeDocGenerator1.Services
{
    public class FileFilterService
    {

        private readonly string[] allowedExtensions =
        {
        ".cs",".js",".ts",".sql",".json",".config",".xml"
        };

        private readonly string[] ignoredFolders =
        {
        "bin","obj","node_modules","packages",".git"
        };

        public List<UploadedFile> FilterImportantFiles(List<UploadedFile> files)
        {
            return files
                .Where(f =>
                    allowedExtensions.Contains(Path.GetExtension(f.FileName).ToLower()) &&
                    !ignoredFolders.Any(x => f.FileName.Contains(x)))
                .Take(300)
                .ToList();
        }
    }
}
