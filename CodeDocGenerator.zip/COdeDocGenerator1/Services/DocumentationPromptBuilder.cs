﻿using COdeDocGenerator1.API.Models;
using System.Text;

namespace COdeDocGenerator1.Services
{
    public static class DocumentationPromptBuilder
    {
        // SINGLE FILE DOCUMENTATION
        public static string BuildPrompt(ParsedCodeResponse file, string documentType)
        {
            var sb = new StringBuilder();

            sb.AppendLine($"DOCUMENT TYPE: {documentType}");
            sb.AppendLine($"FILE NAME: {file.FileName}");
            sb.AppendLine();

            sb.AppendLine("CLASSES AND METHODS:");

            foreach (var cls in file.Classes)
            {
                sb.AppendLine($"Class: {cls.ClassName}");

                foreach (var method in cls.Methods)
                {
                    sb.AppendLine($"  Method: {method.MethodName}");
                    sb.AppendLine($"  Returns: {method.ReturnType}");
                    sb.AppendLine($"  Parameters: {method.Parameters}");
                }
            }

            sb.AppendLine();
            sb.AppendLine("DEPENDENCIES:");
            sb.AppendLine(string.Join(", ", file.Dependencies ?? new List<string>()));

            sb.AppendLine();
            sb.AppendLine("SQL CALLS:");
            sb.AppendLine(string.Join(", ", file.SqlCalls ?? new List<string>()));

            sb.AppendLine();
            sb.AppendLine("SESSION USAGE:");
            sb.AppendLine(string.Join(", ", file.SessionUsage ?? new List<string>()));

            sb.AppendLine();
            sb.AppendLine("VIEWSTATE USAGE:");
            sb.AppendLine(string.Join(", ", file.ViewStateUsage ?? new List<string>()));

            sb.AppendLine();
            sb.AppendLine("Generate professional developer documentation with headings.");

            return sb.ToString();
        }

        // MULTI FILE (ARCHITECTURE)
        public static string BuildMultiFilePrompt(List<ParsedCodeResponse> files)
        {
            return $@"
You are a senior software architect.

Analyze the following project files and generate a COMPLETE architecture document.

Include:

1. System Overview
2. Technology Stack used
3. Project Folder Structure
4. Detailed Architecture Layers
5. Module Responsibilities
6. Component Interaction Flow
7. Database Design (if applicable)
8. Security Architecture
9. Deployment Architecture
10. Future Scalability

Do NOT write generic explanations.
Use actual class names, methods, controllers, services, and models from the project.

Project Code:
{string.Join("\n\n", files.Select(f =>
$@"File: {f.FileName}
Classes: {string.Join(",", f.Classes.Select(c => c.ClassName))}
Methods: {string.Join(",", f.Classes.SelectMany(c => c.Methods).Select(m => m.MethodName))}
Dependencies: {string.Join(",", f.Dependencies ?? new List<string>())}
"))}
";
        }


    }
}