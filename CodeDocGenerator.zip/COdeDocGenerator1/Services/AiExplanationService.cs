﻿using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using COdeDocGenerator1.Services;
using Microsoft.Extensions.Options;

namespace COdeDocGenerator1.API.Services
{
    public class AiExplanationService : IAiExplanationService
    {
        private readonly HttpClient _httpClient;
        private readonly OpenAIOptions _options;

        public AiExplanationService( IOptions<OpenAIOptions> options, HttpClient httpClient)
        {
            _options = options.Value;
            _httpClient = httpClient;

            _httpClient.DefaultRequestHeaders.Authorization =
                new AuthenticationHeaderValue("Bearer", _options.ApiKey);
        }


        public async Task<string> GenerateDocumentationAsync(string prompt)
        {
            var requestBody = new
            {
                model = _options.Model,
                messages = new[]
                {
            new { role = "system", content =
@"You are a Principal .NET Software Architect.

Your job is to generate enterprise-grade technical documentation.

Rules:
- Use clear professional language
- Do not invent functionality not present in the code
- Use headings and structured explanations
- Explain architecture, flow, and risks
- Be concise but complete

Output Format:

1. File Purpose
2. Architectural Context
3. Class Responsibilities
4. Method Behavior
5. Data Access & External Dependencies
6. Security Concerns
7. Performance Considerations
8. Improvement Recommendations
"},
            new { role = "user", content = prompt }
        },
                temperature = 0.1
            };

            var json = JsonSerializer.Serialize(requestBody);

            var response = await _httpClient.PostAsync(
                $"{_options.BaseUrl}/chat/completions",
                new StringContent(json, Encoding.UTF8, "application/json"));

            var responseContent = await response.Content.ReadAsStringAsync();

            if (!response.IsSuccessStatusCode)
                return "Groq API Error: " + responseContent;

            using var doc = JsonDocument.Parse(responseContent);

            return doc.RootElement
                .GetProperty("choices")[0]
                .GetProperty("message")
                .GetProperty("content")
                .GetString() ?? "Empty AI response";
        }

    }
}
