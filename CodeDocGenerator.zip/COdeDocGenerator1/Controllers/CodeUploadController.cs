﻿using Microsoft.AspNetCore.Mvc;
using COdeDocGenerator1.API.Services;
using COdeDocGenerator1.API.Models;
using COdeDocGenerator1.Services;

namespace COdeDocGenerator1.API.Controllers
{
    [ApiController]
    [Route("api/code")]
    public class CodeUploadController : ControllerBase
    {
        private readonly ICodeParserService _parser;
        private readonly IAiExplanationService _aiService;

        public CodeUploadController(
            ICodeParserService parser,
            IAiExplanationService aiService)
        {
            _parser = parser;
            _aiService = aiService;
        }

        [HttpPost("upload")]
        public async Task<IActionResult> UploadCode([FromForm] DocumentRequest request)
        {
            try
            {
                // Validate files
                if (request.Files == null || request.Files.Count == 0)
                    return BadRequest("No files uploaded.");

                // Validate document type
                if (string.IsNullOrWhiteSpace(request.DocumentType))
                    return BadRequest("Document type is required.");

                var parsedFiles = new List<ParsedCodeResponse>();

                foreach (var file in request.Files)
                {
                    if (file.Length == 0)
                        continue;

                    using var reader = new StreamReader(file.OpenReadStream());
                    var content = await reader.ReadToEndAsync();

                    var parsed = _parser.ParseCode(content, file.FileName);

                    if (parsed != null)
                        parsedFiles.Add(parsed);
                }

                if (!parsedFiles.Any())
                    return BadRequest("No valid code files found.");

                string prompt;

                // Architecture document usually needs all files
                if (request.DocumentType.Equals("architecture", StringComparison.OrdinalIgnoreCase))
                {
                    prompt = DocumentationPromptBuilder.BuildMultiFilePrompt(parsedFiles);
                }
                else
                {
                    prompt = DocumentationPromptBuilder.BuildPrompt(parsedFiles.First(), request.DocumentType);
                }

                var aiResult = await _aiService.GenerateDocumentationAsync(prompt);

                var documentation = DocumentationFormatter.EnhanceDocumentation(aiResult, request.DocumentType);

                return Ok(new
                {
                    Success = true,
                    DocumentType = request.DocumentType,
                    FilesProcessed = parsedFiles.Count,
                    Documentation = documentation
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    Success = false,
                    Message = "Error processing files",
                    Error = ex.Message
                });
            }
        }
    }
}